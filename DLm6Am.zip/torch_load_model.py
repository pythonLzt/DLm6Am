import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
# import torchvision
# import torchvision.transforms as transforms
import torch.utils.data as Data
import torch.nn.utils.rnn as rnn_utils
import time
import pickle
import matplotlib.pyplot as plt
from sklearn.metrics import auc, roc_curve, confusion_matrix, accuracy_score
import random
import os
np.set_printoptions(suppress=True)
from sklearn.model_selection import KFold

def seed_torch(seed=104):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed) # if you are using multi-GPU.
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.enabled = False
seed_torch()
torch.manual_seed(104)

def calc(TN, FP, FN, TP):
    SN = TP / (TP + FN)
    SP = TN / (TN + FP)
    # Precision = TP / (TP + FP)
    ACC = (TP + TN) / (TP + TN + FN + FP)
    F1 = (2 * TP) / (2 * TP + FP + FN)
    MCC = (TP * TN - FP * FN) / pow((TP + FN) * (TP + FP) * (TN + FP) * (TN + FN), 0.5)
    return SN, SP, ACC, MCC


def load_features_ind():
    node = np.load(r"D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\class1\m6Am41_motif1_ind13_PN_fuature_xx.npy")
    # node = np.load(r"C:\Users\Charrick\Documents\WeChat Files\wxid_4861878618812\FileStorage\File\2022-04\m6Am41_motif11234_fuature_xx.npy")
    label = np.load(r"D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\class1\m6Am41_motif1_ind1__fuature_yy.npy")

    label1 = label.tolist()
    end_label = []
    for y_label in label1:
        if y_label == [1.0, 0.0]:
            end_label.append(torch.tensor(1))
        if y_label == [0.0, 1.0]:
            end_label.append(torch.tensor(0))
    label = np.array(end_label)
    # print(label)

    return node, label
class newModel1(nn.Module):
    def __init__(self):
        super().__init__()

        self.encoder_layer = nn.TransformerEncoderLayer(d_model=8, nhead=2)
        self.transformer_encoder = nn.TransformerEncoder(self.encoder_layer, num_layers=1)
        self.lstm = nn.LSTM(input_size=8, hidden_size=32, num_layers=2, bidirectional=True, batch_first=True)
        self.lstm_fc = nn.Linear(2624, 256)
        # self.lstm_fc = nn.Linear(2624, 1056)
        # nn.Flatten(),

        self.block2 = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=32, kernel_size=(4, 4), stride=(1, 1), padding=0),  # 32*36
            # nn.MaxPool2d(kernel_size=2),
            nn.Conv2d(in_channels=32, out_channels=64, kernel_size=(4, 4), stride=(1, 1), padding=0),  # 32*33
            nn.MaxPool2d(kernel_size=2),  # 32*17

        )

        self.block3 = nn.Sequential(
            nn.Dropout(p=0.5),
            nn.Linear(1344, 128),
            # nn.Dropout(p=0.5),
            nn.LeakyReLU(),
            # nn.Dropout(p=0.5),
            nn.Linear(128, 12),
            nn.LeakyReLU(),
            nn.Linear(12, 2),
            nn.Softmax(dim=1)

        )

    def forward(self, x):
        x1 = self.transformer_encoder(x)
        x1, (hn, hc) = self.lstm(x1, None)
        x2 = nn.Flatten()(x1)
        x3 = self.lstm_fc(x2)
        x3 = nn.functional.relu(x3)
        # print(x2.shape, "x2.shape")
        # print(x.shape, "x.shape")
        c1 = self.transformer_encoder(x)
        c1 = torch.unsqueeze(c1, 1)
        c2 = self.block2(c1)
        c3 = nn.Flatten()(c2)
        # print(c4.shape, "c4.shape")
        all1 = torch.cat([c3, x3], dim=1)
        # print(all1.shape, "all1.shape")
        # end = self.block3(all1)
        # print(end.shape, "end.shape")
        # print(c3.size())
        end = self.block3(all1)
        return end


class newModel2(nn.Module):
    def __init__(self):
        super().__init__()

        self.encoder_layer = nn.TransformerEncoderLayer(d_model=8, nhead=2)
        self.transformer_encoder = nn.TransformerEncoder(self.encoder_layer, num_layers=1)
        self.lstm = nn.LSTM(input_size=8, hidden_size=32, num_layers=2, bidirectional=True, batch_first=True)
        self.lstm_fc = nn.Linear(2624, 256)
        # self.lstm_fc = nn.Linear(2624, 1056)
        # nn.Flatten(),

        self.block2 = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=32, kernel_size=(4, 4), stride=(1, 1), padding=0),  # 32*36
            # nn.MaxPool2d(kernel_size=2),
            nn.Conv2d(in_channels=32, out_channels=64, kernel_size=(4, 4), stride=(1, 1), padding=0),  # 32*33
            nn.MaxPool2d(kernel_size=2),  # 32*17

        )

        self.block3 = nn.Sequential(
            nn.Dropout(p=0.5),
            nn.Linear(1344, 128),
            # nn.Dropout(p=0.5),
            nn.LeakyReLU(),
            # nn.Dropout(p=0.5),
            nn.Linear(128, 12),
            nn.LeakyReLU(),
            nn.Linear(12, 2),
            nn.Softmax(dim=1)

        )

    def forward(self, x):
        x1 = self.transformer_encoder(x)
        x1, (hn, hc) = self.lstm(x1, None)
        x2 = nn.Flatten()(x1)
        x3 = self.lstm_fc(x2)
        x3 = nn.functional.relu(x3)
        # print(x2.shape, "x2.shape")
        # print(x.shape, "x.shape")
        c1 = self.transformer_encoder(x)
        c1 = torch.unsqueeze(c1, 1)
        c2 = self.block2(c1)
        c3 = nn.Flatten()(c2)
        # print(c4.shape, "c4.shape")
        all1 = torch.cat([c3, x3], dim=1)
        # print(all1.shape, "all1.shape")
        # end = self.block3(all1)
        # print(end.shape, "end.shape")
        # print(c3.size())
        end = self.block3(all1)
        return end


class newModel3(nn.Module):
    def __init__(self):
        super().__init__()

        self.encoder_layer = nn.TransformerEncoderLayer(d_model=8, nhead=2)
        self.transformer_encoder = nn.TransformerEncoder(self.encoder_layer, num_layers=1)
        self.lstm = nn.LSTM(input_size=8, hidden_size=32, num_layers=2, bidirectional=True, batch_first=True)
        self.lstm_fc = nn.Linear(2624, 256)
        # self.lstm_fc = nn.Linear(2624, 1056)
        # nn.Flatten(),

        self.block2 = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=32, kernel_size=(4, 4), stride=(1, 1), padding=0),  # 32*36
            # nn.MaxPool2d(kernel_size=2),
            nn.Conv2d(in_channels=32, out_channels=128, kernel_size=(4, 4), stride=(1, 1), padding=0),  # 32*33
            nn.MaxPool2d(kernel_size=2),  # 32*17

        )

        self.block3 = nn.Sequential(
            nn.Dropout(p=0.5),
            nn.Linear(2432, 256),
            # nn.Dropout(p=0.5),
            nn.LeakyReLU(),
            # nn.Dropout(p=0.5),
            nn.Linear(256, 24),
            nn.LeakyReLU(),
            nn.Linear(24, 2),
            nn.Softmax(dim=1)

        )

    def forward(self, x):
        x1 = self.transformer_encoder(x)
        x1, (hn, hc) = self.lstm(x1, None)
        x2 = nn.Flatten()(x1)
        x3 = self.lstm_fc(x2)
        x3 = nn.functional.relu(x3)
        # print(x2.shape, "x2.shape")
        # print(x.shape, "x.shape")
        c1 = self.transformer_encoder(x)
        c1 = torch.unsqueeze(c1, 1)
        c2 = self.block2(c1)
        c3 = nn.Flatten()(c2)
        # print(c4.shape, "c4.shape")
        all1 = torch.cat([c3, x3], dim=1)
        # print(all1.shape, "all1.shape")
        # end = self.block3(all1)
        # print(end.shape, "end.shape")
        # print(c3.size())
        end = self.block3(all1)
        return end



device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
X_ind, Y_ind = load_features_ind()
index_ind = list(range(0, len(X_ind)))
x_test, y_test = X_ind[index_ind], Y_ind[index_ind]
test_data = torch.tensor(x_test).to(torch.float32).to(device)
test_label = torch.tensor(y_test).to(device)
test_dataset = Data.TensorDataset(test_data, test_label)
test_iter = torch.utils.data.DataLoader(test_dataset, batch_size=32, shuffle=True)
PATH1 = 'D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\m6Am\m6Am41\\net1_59.pth'
PATH2 = 'D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\m6Am\m6Am41\\net2_59.pth'
PATH3 = 'D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\m6Am\m6Am41\\net3_59.pth'

net1 = torch.load(PATH1)
net2 = torch.load(PATH2)
net3 = torch.load(PATH3)

net1.eval()
net2.eval()
net3.eval()

y_predict_1 = []
y_predict_2 = []
y_predict_3 = []
y_test_class = []

with torch.no_grad():
    for seq1, label1 in test_iter:
        # print(label1)
        pred1 = net1(seq1)
        pred2 = net2(seq1)
        pred3 = net3(seq1)
        # print(type(pred))
        x_p1 = pred1.data.cpu().numpy().tolist()
        x_p2 = pred2.data.cpu().numpy().tolist()
        x_p3 = pred3.data.cpu().numpy().tolist()
        y_p = label1.data.cpu().numpy().tolist()
        # print(x_p1,"111111111")
        # print(x_p2,"222222222")
        # print(x_p3,"333333333")

        for p_list1 in x_p1:
            y_predict_1.append(p_list1)
        for p_list2 in x_p2:
            y_predict_2.append(p_list2)
        for p_list3 in x_p3:
            y_predict_3.append(p_list3)

        y_test_class += y_p

    y_predict_1 = np.array(y_predict_1)
    y_predict_2 = np.array(y_predict_2)
    y_predict_3 = np.array(y_predict_3)
    y_test_class = np.array(y_test_class)
    probs_x1 = ((y_predict_1[:, 1] + y_predict_2[:, 1] + y_predict_3[:, 1]) / 3).flatten().tolist()
    # print(probs_x1)
    # print(len(probs_x1))
    labels = y_test_class.flatten().tolist()
    y_predict_class_1 = np.argmax(y_predict_1, axis=1)
    y_predict_class_2 = np.argmax(y_predict_2, axis=1)
    y_predict_class_3 = np.argmax(y_predict_3, axis=1)
    prediction_labels_end = []
    for num in range(len(y_test_class)):
        judge = y_predict_class_1[num] + y_predict_class_2[num] + y_predict_class_3[num]
        if judge > 1.5:
            prediction_labels_end += [1]
        else:
            prediction_labels_end += [0]
    prediction_labels_end1 = np.array(prediction_labels_end)
    tn, fp, fn, tp = confusion_matrix(y_test_class, prediction_labels_end1).ravel()
    print("tn, fp, fn, tp={},{},{},{}".format(tn, fp, fn, tp))
    sn, sp, acc, mcc = calc(float(tn), float(fp), float(fn), float(tp))
    print('sn=%.4f' % sn, ',sp=%.4f' % sp, ',acc=%.4f' % acc, ',mcc=%.4f' % mcc)
    fpr, tpr, thresholds = roc_curve(y_test_class, probs_x1, pos_label=1)
    # np.save('D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\m6Am\m6Am41\结果\ind_m6Am_inter_attention_fpr.npy', fpr)
    # np.save('D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\m6Am\m6Am41\结果\ind_m6Am_inter_attention_tpr.npy', tpr)

    roc_auc = auc(fpr, tpr)  # auc为Roc曲线下的面积
    print("tn, fp, fn, tp={},{},{},{}".format(tn, fp, fn, tp), ',acc=%.4f' % acc, 'sn=%.4f' % sn, ',sp=%.4f' % sp,',mcc=%.4f' % mcc, 'AUC=', roc_auc)

    test_acc = accuracy_score(prediction_labels_end1, y_test_class)
    lw = 2
    plt.figure(figsize=(10, 10))
    plt.plot(fpr, tpr, lw=lw, label='ROC curve (AUC = %.4f)' % roc_auc)  ###假正率为横坐标，真正率为纵坐标做曲线
    plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.0])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver operating characteristic example')
    plt.legend(loc="lower right")
    # plt.savefig('D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\m6Am\m6Am41\m6Am_test.pdf',dpi=500)
    plt.show()















