import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
# import torchvision
# import torchvision.transforms as transforms
import torch.utils.data as Data
import torch.nn.utils.rnn as rnn_utils
import time
import pickle
import matplotlib.pyplot as plt
from sklearn.metrics import auc, roc_curve, confusion_matrix, accuracy_score
import random
import argparse
import os
from Bio import SeqIO

# f = open('D:\pandas数据\pandas课件\项目\数组.txt','w')


np.set_printoptions(suppress=True)
from sklearn.model_selection import KFold

def seed_torch(seed=104):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed) # if you are using multi-GPU.
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.enabled = False
seed_torch()
torch.manual_seed(104)

def calc(TN, FP, FN, TP):
    SN = TP / (TP + FN)
    SP = TN / (TN + FP)
    # Precision = TP / (TP + FP)
    ACC = (TP + TN) / (TP + TN + FN + FP)
    F1 = (2 * TP) / (2 * TP + FP + FN)
    MCC = (TP * TN - FP * FN) / pow((TP + FN) * (TP + FP) * (TN + FP) * (TN + FN), 0.5)
    return SN, SP, ACC, MCC


def load_features_ind(sample_name):
    AA_all = []
    AA_name = []
    aa = 0

    for my_a in SeqIO.parse(sample_name, 'fasta'):
        my_aa = my_a.seq
        if len(my_aa) == 41:
            aa += 1
        if len(my_aa) > 41:
            nu1_num1 = 0

            for nu1 in range(len(my_aa[20:-21])):
                if my_aa[nu1 + 20] == 'A':
                    aa += 1
    print('aa:',aa)
    # aa = len(list(seq))
    i = 0
    p = np.zeros((aa, 41, 4))
    pp = p.copy()

    pp3 = p.copy()

    for my_pp in SeqIO.parse(sample_name,'fasta'):
        # AA = str(my_pp.seq)
        if len(my_pp.seq) == 41:
            AA = str(my_pp.seq)
            AA_all.append(21)
            AA_name.append(str(my_pp.description))
            pp[i] = chemical_properties(AA)

            pp3[i] = AA_ONE_HOT(AA)
            i += 1
        if len(my_pp.seq) > 41:
            add_supp = 0
            for nu1 in range(len(my_pp.seq[20:-21])):
                if my_pp.seq[nu1 + 20] == 'A':
                    AA = my_pp.seq[nu1:nu1+41]
                    AA_all.append(int(nu1 + 21))
                    pp[i] = chemical_properties(AA)
                    pp3[i] = AA_ONE_HOT(AA)
                    add_supp += 1
                    i += 1
            for supp in range(add_supp):
                AA_name.append(str(my_pp.description))
    print('name:',len(AA_name))
    print('i:',i)
    xx_all = np.concatenate((pp, pp3), axis=2)



    # node1, xulie = first_feature_extraction(sample_name)
    # # node = np.load(r"C:\Users\Charrick\Documents\WeChat Files\wxid_4861878618812\FileStorage\File\2022-04\m6Am41_motif11234_fuature_xx.npy")
    # node2 = third_feature_extraction(sample_name)
    # print(node1.shape,'1111')
    # print(node2.shape,'2222')
    #
    # node = np.concatenate((node1, node2), axis=2)


    return AA_name, AA_all, xx_all

def AA_ONE_HOT(AA):
    one_hot_dict = {
        'A': [1, 0, 0, 0],
        'C': [0, 1, 0, 0],
        'G': [0, 0, 1, 0],
        'U': [0, 0, 0, 1]
    }
    coding_arr = np.zeros((len(AA),4), dtype=float)
    for m in range(len(AA)):
        coding_arr[m] = one_hot_dict[AA[m]]
        # print(coding_arr[m])
    return coding_arr

def chemical_properties(AA):
    one_hot_dict = {
        'A': [1, 1, 1],
        'C': [0, 0, 1],
        'G': [1, 0, 0],
        'U': [0, 1, 0]
    }
    coding_arr = np.zeros((len(AA), 4), dtype=float)
    # for m in range(len(AA)):
    A_num = 0
    C_num = 0
    G_num = 0
    U_num = 0
    All_num = 0
    for x in AA:
        if x == "A":
            All_num += 1
            A_num += 1
            Density = A_num/All_num
            coding_arr[All_num-1] = one_hot_dict[AA[All_num-1]] + [Density]
        if x == "C":
            All_num += 1
            C_num += 1
            Density = C_num/All_num
            coding_arr[All_num-1] = one_hot_dict[AA[All_num-1]] + [Density]
        if x == "G":
            All_num += 1
            G_num += 1
            Density = G_num/All_num
            coding_arr[All_num-1] = one_hot_dict[AA[All_num-1]] + [Density]
        if x == "U":
            All_num += 1
            U_num += 1
            Density = U_num/All_num
            coding_arr[All_num-1] = one_hot_dict[AA[All_num-1]] + [Density]

        # print(coding_arr)
    return coding_arr


# def first_feature_extraction(sample_name):
#
#     se_pp = (sample_name)
#     # se_nn = ("D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\class1\独立测试\\" + sample_name + "_N.fasta")
#     se_p = SeqIO.parse(se_pp, 'fasta')
#     #     if len(se_p.seq) == 41:
#
#
#     aa = len(list(se_p))
#     # bb = len(list(se_n))
#     # print(aa)
#     # print(bb)
#     i = 0
#     j = 0
#     p = np.zeros((aa, 41, 4))
#     p_label = np.zeros((aa, 2))
#
#     pp = p.copy()
#     pp_label = p_label.copy()
#
#     AA_ALL = []
#     for my_pp in SeqIO.parse(se_pp,'fasta'):
#         AA = str(my_pp.seq)
#         AA_ALL.append(AA)
#
#         pp[i] = chemical_properties(AA)
#         pp_label[i] = [1, 0]
#         # print(pp_label[i])
#         i += 1
#     # print(AA_ALL)
#     # print(type(AA_ALL))
#     # for my_nn in SeqIO.parse(se_nn,'fasta'):
#     #     AA = str(my_nn.seq)
#     #     nn[j] = chemical_properties(AA)
#     #     nn_label[j] = [0, 1]
#     #     j += 1
#
#     Z_Mays_xx_all = np.array(pp[:aa])
#     # Z_Mays_yy_all = np.vstack([pp_label[:aa], nn_label[:bb]])
#     # Z_Mays_xx_all = Z_Mays_xx_all.reshape(len(Z_Mays_xx_all), -1)
#     # Z_Mays_yy_all = Z_Mays_yy_all.reshape(len(Z_Mays_yy_all), -1)
#
#     # print(Z_Mays_xx_all.shape)
#     # print(Z_Mays_yy_all.shape)
#
#     # print(Z_Mays_xx_all[1:2])
#     # print(Z_Mays_yy_all[1:2])
#     # np.save(sample_name + 'chemical_properties__fuature_xx.npy', Z_Mays_xx_all)
#     # np.save(sample_name + '1__fuature_yy.npy', Z_Mays_yy_all)
#     return Z_Mays_xx_all, AA_ALL

# def third_feature_extraction(sample_name):
#     se_pp = (sample_name)
#     # se_nn = ("D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\class1\独立测试\\" + sample_name + "_N.fasta")
#     se_p = SeqIO.parse(se_pp, 'fasta')
#     # se_n = SeqIO.parse(se_nn, 'fasta')
#     # print(str(se_p.seq))
#     aa = len(list(se_p))
#     # bb = len(list(se_n))
#     print(aa)
#     # print(bb)
#     i = 0
#     j = 0
#     p = np.zeros((aa, 41, 4))
#     p_label = np.zeros((aa, 2))
#     # n = np.zeros((bb, 41, 4))
#     # n_label = np.zeros((bb, 2))
#     pp = p.copy()
#     pp_label = p_label.copy()
#     # nn = n.copy()
#     # nn_label = n_label.copy()
#     for my_pp in SeqIO.parse(se_pp,'fasta'):
#         AA = str(my_pp.seq)
#         pp[i] = AA_ONE_HOT(AA)
#         pp_label[i] = [1, 0]
#         i += 1
#
#     # for my_nn in SeqIO.parse(se_nn,'fasta'):
#     #     AA = str(my_nn.seq)
#     #     nn[j] = AA_ONE_HOT(AA)
#     #     nn_label[j] = [0, 1]
#     #     j += 1
#     Z_Mays_xx_all = np.array(pp[:aa])
#     # Z_Mays_yy_all = np.vstack([pp_label[:aa], nn_label[:bb]])
#     # Z_Mays_xx_all = Z_Mays_xx_all.reshape(len(Z_Mays_xx_all), -1)
#     # Z_Mays_yy_all = Z_Mays_yy_all.reshape(len(Z_Mays_yy_all), -1)
#
#     # Z_Mays_xx_all = nn[:bb]#np.vstack([pp[:aa], nn[:bb]])
#     # Z_Mays_yy_all = nn_label[:bb]#np.vstack([pp_label[:aa], nn_label[:bb]])
#     print(Z_Mays_xx_all.shape)
#     # print(Z_Mays_yy_all.shape)
#     # print(Z_Mays_xx_all[1:2])
#     # print(Z_Mays_yy_all[1:2])
#     # np.save(sample_name + '_Binary__fuature_xx.npy', Z_Mays_xx_all)
#     # np.save(sample_name + '3__fuature_yy.npy', Z_Mays_yy_all)
#     return Z_Mays_xx_all


class newModel1(nn.Module):
    def __init__(self):
        super().__init__()

        self.encoder_layer = nn.TransformerEncoderLayer(d_model=8, nhead=2)
        self.transformer_encoder = nn.TransformerEncoder(self.encoder_layer, num_layers=1)
        self.lstm = nn.LSTM(input_size=8, hidden_size=32, num_layers=2, bidirectional=True, batch_first=True)
        self.lstm_fc = nn.Linear(2624, 256)
        # self.lstm_fc = nn.Linear(2624, 1056)
        # nn.Flatten(),

        self.block2 = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=32, kernel_size=(4, 4), stride=(1, 1), padding=0),  # 32*36
            # nn.MaxPool2d(kernel_size=2),
            nn.Conv2d(in_channels=32, out_channels=64, kernel_size=(4, 4), stride=(1, 1), padding=0),  # 32*33
            nn.MaxPool2d(kernel_size=2),  # 32*17

        )

        self.block3 = nn.Sequential(
            nn.Dropout(p=0.5),
            nn.Linear(1344, 128),
            # nn.Dropout(p=0.5),
            nn.LeakyReLU(),
            # nn.Dropout(p=0.5),
            nn.Linear(128, 12),
            nn.LeakyReLU(),
            nn.Linear(12, 2),
            nn.Softmax(dim=1)

        )

    def forward(self, x):
        x1 = self.transformer_encoder(x)
        x1, (hn, hc) = self.lstm(x1, None)
        x2 = nn.Flatten()(x1)
        x3 = self.lstm_fc(x2)
        x3 = nn.functional.relu(x3)
        # print(x2.shape, "x2.shape")
        # print(x.shape, "x.shape")
        c1 = self.transformer_encoder(x)
        c1 = torch.unsqueeze(c1, 1)
        c2 = self.block2(c1)
        c3 = nn.Flatten()(c2)
        # print(c4.shape, "c4.shape")
        all1 = torch.cat([c3, x3], dim=1)
        # print(all1.shape, "all1.shape")
        # end = self.block3(all1)
        # print(end.shape, "end.shape")
        # print(c3.size())
        end = self.block3(all1)
        return end


class newModel2(nn.Module):
    def __init__(self):
        super().__init__()

        self.encoder_layer = nn.TransformerEncoderLayer(d_model=8, nhead=2)
        self.transformer_encoder = nn.TransformerEncoder(self.encoder_layer, num_layers=1)
        self.lstm = nn.LSTM(input_size=8, hidden_size=32, num_layers=2, bidirectional=True, batch_first=True)
        self.lstm_fc = nn.Linear(2624, 256)
        # self.lstm_fc = nn.Linear(2624, 1056)
        # nn.Flatten(),

        self.block2 = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=32, kernel_size=(4, 4), stride=(1, 1), padding=0),  # 32*36
            # nn.MaxPool2d(kernel_size=2),
            nn.Conv2d(in_channels=32, out_channels=64, kernel_size=(4, 4), stride=(1, 1), padding=0),  # 32*33
            nn.MaxPool2d(kernel_size=2),  # 32*17

        )

        self.block3 = nn.Sequential(
            nn.Dropout(p=0.5),
            nn.Linear(1344, 128),
            # nn.Dropout(p=0.5),
            nn.LeakyReLU(),
            # nn.Dropout(p=0.5),
            nn.Linear(128, 12),
            nn.LeakyReLU(),
            nn.Linear(12, 2),
            nn.Softmax(dim=1)

        )

    def forward(self, x):
        x1 = self.transformer_encoder(x)
        x1, (hn, hc) = self.lstm(x1, None)
        x2 = nn.Flatten()(x1)
        x3 = self.lstm_fc(x2)
        x3 = nn.functional.relu(x3)
        # print(x2.shape, "x2.shape")
        # print(x.shape, "x.shape")
        c1 = self.transformer_encoder(x)
        c1 = torch.unsqueeze(c1, 1)
        c2 = self.block2(c1)
        c3 = nn.Flatten()(c2)
        # print(c4.shape, "c4.shape")
        all1 = torch.cat([c3, x3], dim=1)
        # print(all1.shape, "all1.shape")
        # end = self.block3(all1)
        # print(end.shape, "end.shape")
        # print(c3.size())
        end = self.block3(all1)
        return end


class newModel3(nn.Module):
    def __init__(self):
        super().__init__()

        self.encoder_layer = nn.TransformerEncoderLayer(d_model=8, nhead=2)
        self.transformer_encoder = nn.TransformerEncoder(self.encoder_layer, num_layers=1)
        self.lstm = nn.LSTM(input_size=8, hidden_size=32, num_layers=2, bidirectional=True, batch_first=True)
        self.lstm_fc = nn.Linear(2624, 256)
        # self.lstm_fc = nn.Linear(2624, 1056)
        # nn.Flatten(),

        self.block2 = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=32, kernel_size=(4, 4), stride=(1, 1), padding=0),  # 32*36
            # nn.MaxPool2d(kernel_size=2),
            nn.Conv2d(in_channels=32, out_channels=128, kernel_size=(4, 4), stride=(1, 1), padding=0),  # 32*33
            nn.MaxPool2d(kernel_size=2),  # 32*17

        )

        self.block3 = nn.Sequential(
            nn.Dropout(p=0.5),
            nn.Linear(2432, 256),
            # nn.Dropout(p=0.5),
            nn.LeakyReLU(),
            # nn.Dropout(p=0.5),
            nn.Linear(256, 24),
            nn.LeakyReLU(),
            nn.Linear(24, 2),
            nn.Softmax(dim=1)

        )

    def forward(self, x):
        x1 = self.transformer_encoder(x)
        x1, (hn, hc) = self.lstm(x1, None)
        x2 = nn.Flatten()(x1)
        x3 = self.lstm_fc(x2)
        x3 = nn.functional.relu(x3)
        # print(x2.shape, "x2.shape")
        # print(x.shape, "x.shape")
        c1 = self.transformer_encoder(x)
        c1 = torch.unsqueeze(c1, 1)
        c2 = self.block2(c1)
        c3 = nn.Flatten()(c2)
        # print(c4.shape, "c4.shape")
        all1 = torch.cat([c3, x3], dim=1)
        # print(all1.shape, "all1.shape")
        # end = self.block3(all1)
        # print(end.shape, "end.shape")
        # print(c3.size())
        end = self.block3(all1)
        return end

if __name__ == '__main__':

    parser = argparse.ArgumentParser()

    parser.add_argument("-test_fasta", action="store", dest='test_fasta', required=True,
                        help="test fasta file")

    parser.add_argument("-out_dir", action="store", dest='out_dir', required=True,
                        help="output directory")

    args = parser.parse_args()
    test_fa = args.test_fasta


    device = torch.device("cpu")
    AA_name, xulie, x_test = load_features_ind(test_fa)
    # index_ind = list(range(0, len(X_ind)))
    # x_test, y_test = X_ind[index_ind], Y_ind[index_ind]
    test_data = torch.tensor(x_test).to(torch.float32).to(device)
    # test_label = torch.tensor(y_test).to(device)
    test_dataset = Data.TensorDataset(test_data)
    test_iter = torch.utils.data.DataLoader(test_dataset, batch_size=32)
    PATH1 = 'net_1_59.pth'
    PATH2 = 'net_2_59.pth'
    PATH3 = 'net_3_59.pth'
    net1 = newModel1().to(device)
    net2 = newModel2().to(device)
    net3 = newModel3().to(device)

    state1 = torch.load(PATH1,map_location= 'cpu')
    net1.load_state_dict(state1['model_state'])
    state2 = torch.load(PATH2,map_location= 'cpu')
    net2.load_state_dict(state2['model_state'])
    state3 = torch.load(PATH3,map_location= 'cpu')
    net3.load_state_dict(state3['model_state'])


    net1.eval()
    net2.eval()
    net3.eval()

    y_predict_1 = []
    y_predict_2 = []
    y_predict_3 = []
    y_test_class = []
    write_tp = []
    with torch.no_grad():
        for seq1 in test_iter:

            # print(type(seq1))
            # print(seq1)
            seq1 = seq1[0]
            pred1 = net1(seq1)
            pred2 = net2(seq1)
            pred3 = net3(seq1)
            # print(type(pred))
            x_p1 = pred1.data.cpu().numpy().tolist()
            x_p2 = pred2.data.cpu().numpy().tolist()
            x_p3 = pred3.data.cpu().numpy().tolist()
            # y_p = label1.data.cpu().numpy().tolist()
            # print(x_p1,"111111111")
            # print(x_p2,"222222222")
            # print(x_p3,"333333333")

            for p_list1 in x_p1:
                y_predict_1.append(p_list1)
            for p_list2 in x_p2:
                y_predict_2.append(p_list2)
            for p_list3 in x_p3:
                y_predict_3.append(p_list3)

            # y_test_class += y_p

        y_predict_1 = np.array(y_predict_1)
        y_predict_2 = np.array(y_predict_2)
        y_predict_3 = np.array(y_predict_3)
        # y_test_class = np.array(y_test_class)
        probs_x1 = ((y_predict_1[:, 1] + y_predict_2[:, 1] + y_predict_3[:, 1]) / 3).flatten().tolist()
        # print(probs_x1)
        # print(len(probs_x1))
        # labels = y_test_class.flatten().tolist()
        y_predict_class_1 = np.argmax(y_predict_1, axis=1)
        y_predict_class_2 = np.argmax(y_predict_2, axis=1)
        y_predict_class_3 = np.argmax(y_predict_3, axis=1)
        prediction_labels_end = []
        # print(xulie)
        for num in range(len(y_predict_class_1)):
            judge = y_predict_class_1[num] + y_predict_class_2[num] + y_predict_class_3[num]
            # print(xulie_)
            if judge > 1.5:
                prediction_labels_end = '+'
            else:
                prediction_labels_end = '-'
            xulie_ = str(str(AA_name[num]) + ' ' + str(xulie[num]) + ' ' + str(probs_x1[num]))
            write_tp.append([str(num), xulie[num], prediction_labels_end, str(probs_x1[num])])
    df = pd.DataFrame(write_tp, columns=['num', 'seq', 'pred', 'prob'])
    model_path = args.out_dir
    if not os.path.exists(model_path):
        os.makedirs(model_path)

    df.to_excel('./' + model_path + '/result.xlsx',index=False)
        # prediction_labels_end1 = np.array(prediction_labels_end)
        # tn, fp, fn, tp = confusion_matrix(y_test_class, prediction_labels_end1).ravel()
        # print("tn, fp, fn, tp={},{},{},{}".format(tn, fp, fn, tp))
        # sn, sp, acc, mcc = calc(float(tn), float(fp), float(fn), float(tp))
        # print('sn=%.4f' % sn, ',sp=%.4f' % sp, ',acc=%.4f' % acc, ',mcc=%.4f' % mcc)
        # fpr, tpr, thresholds = roc_curve(y_test_class, probs_x1, pos_label=1)
        # # np.save('D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\m6Am\m6Am41\结果\ind_m6Am_inter_attention_fpr.npy', fpr)
        # # np.save('D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\m6Am\m6Am41\结果\ind_m6Am_inter_attention_tpr.npy', tpr)
        #
        # roc_auc = auc(fpr, tpr)  # auc为Roc曲线下的面积
        # print("tn, fp, fn, tp={},{},{},{}".format(tn, fp, fn, tp), ',acc=%.4f' % acc, 'sn=%.4f' % sn, ',sp=%.4f' % sp,',mcc=%.4f' % mcc, 'AUC=', roc_auc)
        #
        # # test_acc = accuracy_score(prediction_labels_end1, y_test_class)
        # lw = 2
        # plt.figure(figsize=(10, 10))
        # plt.plot(fpr, tpr, lw=lw, label='ROC curve (AUC = %.4f)' % roc_auc)  ###假正率为横坐标，真正率为纵坐标做曲线
        # plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
        # plt.xlim([0.0, 1.0])
        # plt.ylim([0.0, 1.0])
        # plt.xlabel('False Positive Rate')
        # plt.ylabel('True Positive Rate')
        # plt.title('Receiver operating characteristic example')
        # plt.legend(loc="lower right")
        # # plt.savefig('D:\Pycharm\PyCharm Community Edition 2020.1.4\holle world\m6Am\m6Am41\m6Am_test.pdf',dpi=500)
        # plt.show()















